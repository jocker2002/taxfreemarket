HammerJS Project: http://hammerjs.github.io/

The MIT License (MIT)

Copyright (c) 2011 by Jorik Tangelder (Eight Media)